import { Component } from '@angular/core';

@Component({
  selector: 'app-issue-card',
  imports: [],
  templateUrl: './issue-card.html',
  styleUrl: './issue-card.css',
})
export class IssueCard {

}
